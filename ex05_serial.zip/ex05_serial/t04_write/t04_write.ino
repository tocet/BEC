#define BAUDRATE 115200

void setup() {
 Serial.begin(BAUDRATE); }

void loop() {
 Serial.write(0x48); // H
 Serial.write(0x65); // e
 Serial.write(0x6C); // l
 Serial.write(0x6C); // l
 Serial.write(0x6F); // o
 Serial.write(0x21); // !
 Serial.write(0x0A); // \n
 delay(500); }
