#define BAUDRATE 115200

char serial_data;

void setup() {
 Serial.begin(BAUDRATE); }

void loop() {
 if(Serial.available()>0) {
 switch(Serial.read()) {
  case 'A':
    Serial.println("A was sent");
    break;

  case 'P':
    Serial.println("P was sent");
    break;

  case '1':
    Serial.println("1 was sent");
    break;

  default:
    Serial.println("Unrecognized value");
    break;
  }
 }
}
